﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class AddScore : MonoBehaviour
{
    public static int Score = 0;
    public Text ScoreText;

    public void Add1()
    {
        Score++;
    }

    public void ChangeScene()
    {
        SceneManager.LoadScene(1);
    }

    private void Update()
    {
        ScoreText.text = "Score: " + Score.ToString();
    }
}
