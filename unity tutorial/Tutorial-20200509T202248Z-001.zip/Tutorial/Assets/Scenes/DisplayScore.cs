﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DisplayScore : MonoBehaviour
{
    public Text ScoreText;

    void Start()
    {
        ScoreText.text = "Score: " + AddScore.Score.ToString();
    }
}
